class TestsController < ApplicationController
  def index
  end
  



end
