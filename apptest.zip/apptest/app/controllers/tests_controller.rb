class TestsController < ApplicationController
	def index
		puts "INDEXXX"
  end

  def add
  	puts "ADDED"
  end

	def show
		@name = params[:name]

		@user = User.all

		#user = User.create(name: "Shah Rukh", pass: "abcd")

	end

  def new


  end

  def create
  	@user = User.create(name: params[:name], pass: params[:pass])
		#@user = User.new(params[:name])
		#@user = User.new(params[:pass])
 		@user.save
  	redirect_to "/tests/show"
  end

  def destroy
  	puts "Helloooooo"
  	puts params[:id]
    @user = User.find(params[:id])

    @user.destroy
 
    redirect_to articles_path
  end


end
